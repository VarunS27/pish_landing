// Lightweight Supabase client wrapper using fetch API
// Compatible with Chrome extension CSP (no external scripts)

class SupabaseClient {
  constructor(url, anonKey) {
    this.url = url;
    this.anonKey = anonKey;
    this.headers = {
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
    };
  }

  from(table) {
    return new SupabaseQueryBuilder(this.url, this.headers, table);
  }

  storage = {
    from: (bucket) => ({
      upload: async (path, file, options = {}) => {
        const formData = new FormData();
        formData.append("file", file);
        const response = await fetch(
          `${this.url}/storage/v1/object/${bucket}/${path}`,
          {
            method: "POST",
            headers: {
              apikey: this.anonKey,
              Authorization: `Bearer ${this.anonKey}`,
            },
            body: formData,
          }
        );
        if (!response.ok) {
          let error;
          try {
            error = await response.json();
          } catch (e) {
            error = {
              message: `Upload failed: ${response.status} ${response.statusText}`,
              status: response.status,
            };
          }
          return { data: null, error };
        }
        let data;
        try {
          data = await response.json();
        } catch (e) {
          // Some uploads return empty body on success
          data = { path: path };
        }
        return { data: { path: data.path || path }, error: null };
      },
      getPublicUrl: (path) => ({
        data: {
          publicUrl: `${this.url}/storage/v1/object/public/${bucket}/${path}`,
        },
      }),
    }),
  };

  rpc(functionName, params = {}) {
    return new Promise(async (resolve) => {
      const response = await fetch(
        `${this.url}/rest/v1/rpc/${functionName}`,
        {
          method: "POST",
          headers: this.headers,
          body: JSON.stringify(params),
        }
      );

      if (!response.ok) {
        const error = await response.json().catch(() => ({
          message: `RPC call failed: ${response.statusText}`,
        }));
        resolve({ data: null, error });
        return;
      }

      // RPC can return void or data
      const text = await response.text();
      let data = null;
      if (text) {
        try {
          data = JSON.parse(text);
        } catch (e) {
          // Some RPC functions return empty body
          data = null;
        }
      }

      resolve({ data, error: null });
    });
  }
}

class SupabaseQueryBuilder {
  constructor(url, headers, table) {
    this.url = url;
    this.headers = headers;
    this.table = table;
    this.selectCols = "*";
    this.filters = [];
    this.orderBy = null;
    this.limitCount = null;
    this.singleMode = false;
    this.insertMode = false;
    this.insertData = null;
    this.updateMode = false;
    this.updateData = null;
  }

  select(columns = "*") {
    this.selectCols = columns;
    return this;
  }

  eq(column, value) {
    this.filters.push(`${column}=eq.${encodeURIComponent(value)}`);
    return this;
  }

  order(column, { ascending = true } = {}) {
    this.orderBy = `${column}.${ascending ? "asc" : "desc"}`;
    return this;
  }

  limit(count) {
    this.limitCount = count;
    return this;
  }

  single() {
    this.singleMode = true;
    return this;
  }

  insert(data) {
    // Store insert data and return this for chaining
    this.insertData = Array.isArray(data) ? data : [data];
    this.insertMode = true;
    return this;
  }

  async executeInsert() {
    const url = `${this.url}/rest/v1/${this.table}`;
    const params = [];
    
    // If select was called, add it to the query
    if (this.selectCols && this.selectCols !== "*") {
      params.push(`select=${encodeURIComponent(this.selectCols)}`);
    }
    
    const queryString = params.length > 0 ? `?${params.join("&")}` : "";
    
    const response = await fetch(url + queryString, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify(this.insertData),
    });

    if (!response.ok) {
      const error = await response.json();
      return { data: null, error };
    }

    const result = await response.json();
    
    // Handle single mode if set
    if (this.singleMode) {
      if (Array.isArray(result) && result.length > 0) {
        return { data: result[0], error: null };
      } else if (Array.isArray(result) && result.length === 0) {
        return { data: null, error: { message: "No rows returned" } };
      } else {
        return { data: result, error: null };
      }
    }
    
    return {
      data: Array.isArray(this.insertData) && this.insertData.length === 1 
        ? (Array.isArray(result) ? result[0] : result) 
        : result,
      error: null,
    };
  }

  update(data) {
    // Store update data and return this for chaining
    this.updateData = data;
    this.updateMode = true;
    return this;
  }

  async executeUpdate() {
    let url = `${this.url}/rest/v1/${this.table}`;
    if (this.filters.length > 0) {
      url += `?${this.filters.join("&")}`;
    }

    const response = await fetch(url, {
      method: "PATCH",
      headers: this.headers,
      body: JSON.stringify(this.updateData),
    });

    if (!response.ok) {
      const error = await response.json();
      return { data: null, error };
    }

    const result = await response.json();
    return { data: result, error: null };
  }

  async executeSelect() {
    let url = `${this.url}/rest/v1/${this.table}`;
    const params = [];

    if (this.selectCols !== "*") {
      params.push(`select=${encodeURIComponent(this.selectCols)}`);
    }
    if (this.filters.length > 0) {
      params.push(...this.filters);
    }
    if (this.orderBy) {
      params.push(`order=${this.orderBy}`);
    }
    if (this.limitCount) {
      params.push(`limit=${this.limitCount}`);
    }

    if (params.length > 0) {
      url += `?${params.join("&")}`;
    }

    const response = await fetch(url, {
      method: "GET",
      headers: this.headers,
    });

    if (!response.ok) {
      const error = await response.json();
      return { data: null, error };
    }

    const result = await response.json();
    
    // Handle single mode
    if (this.singleMode) {
      if (Array.isArray(result) && result.length > 0) {
        return { data: result[0], error: null };
      } else if (Array.isArray(result) && result.length === 0) {
        return { data: null, error: { message: "No rows returned" } };
      } else {
        return { data: result, error: null };
      }
    }
    
    return { data: result, error: null };
  }

  // Make the query builder thenable/awaitable
  then(onFulfilled, onRejected) {
    if (this.insertMode) {
      return this.executeInsert().then(onFulfilled, onRejected);
    }
    if (this.updateMode) {
      return this.executeUpdate().then(onFulfilled, onRejected);
    }
    return this.executeSelect().then(onFulfilled, onRejected);
  }
}

export function createClient(url, anonKey) {
  return new SupabaseClient(url, anonKey);
}

