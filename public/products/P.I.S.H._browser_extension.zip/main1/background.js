// background.js - service worker for Phishing Guardian
// Handles Supabase, Gemini, VirusTotal, SMS, navigation events, screenshots, and persistence.

import { createClient } from "./supabase-client.js";

// TODO: Replace with your real values
const SUPABASE_URL = "https://ihmvjcwnmdrpcvkoqhis.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlobXZqY3dubWRycGN2a29xaGlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ1ODUxNTAsImV4cCI6MjA4MDE2MTE1MH0.LaUr84Lw3LzeqBjfKi7Lf-CZf62LyhcrzOJ3ZuYO-pE";
const GEMINI_API_KEY = "AIzaSyAAHZ6KiTjTKP2qWWDz-cTfWeAwKY312ag";
const GEMINI_MODEL = "gemini-2.0-flash-lite";
const VIRUSTOTAL_API_KEY = "039dd28549e7aeba925bbd4fbcbd0cc872c82e0e704ae3fc37ad4f12d83e6eaf";
const SMS_API_URL = "https://your-sms-provider.example.com/send";
const SMS_API_KEY = "YOUR_SMS_API_KEY";
const ALERT_PHONE_NUMBER = "+919699092008";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Utility: get current logged-in user info from chrome.storage
async function getCurrentUser() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["pg_user"], (data) => {
      const user = data.pg_user || null;
      console.log("[getCurrentUser] Retrieved user:", user ? { id: user.id, email: user.user_email } : "null");
      resolve(user);
    });
  });
}

// Utility: store latest page_event_id per tabId
async function setTabPageEvent(tabId, pageEventId) {
  return new Promise((resolve) => {
    chrome.storage.local.set(
      {
        [`page_event_${tabId}`]: pageEventId,
      },
      () => resolve()
    );
  });
}

async function getTabPageEvent(tabId) {
  return new Promise((resolve) => {
    chrome.storage.local.get([`page_event_${tabId}`], (data) => {
      resolve(data[`page_event_${tabId}`] || null);
    });
  });
}

// Listen for navigation events to trigger content capture and screenshot
chrome.webNavigation.onCompleted.addListener(async (details) => {
  console.log("[Navigation] onCompleted event:", { tabId: details.tabId, url: details.url, frameId: details.frameId });
  if (details.frameId !== 0) {
    console.log("[Navigation] Skipping non-top frame");
    return; // only top frame
  }

  // Ask content script to extract forensics
  try {
    console.log("[Navigation] Sending PG_EXTRACT_FORENSICS to tab", details.tabId);
    chrome.tabs.sendMessage(details.tabId, { type: "PG_EXTRACT_FORENSICS" });
  } catch (e) {
    console.log("[Navigation] Failed to send message to tab (may not have content script):", e.message);
    // Tab might not have content script (e.g., chrome:// pages)
  }

  // Capture screenshot for this tab
  try {
    console.log("[Navigation] Capturing screenshot for tab", details.tabId);
    const imageDataUrl = await chrome.tabs.captureVisibleTab(details.windowId, {
      format: "png",
    });
    console.log("[Navigation] Screenshot captured, size:", imageDataUrl.length, "chars");
    await handleScreenshot(details.tabId, details.url, imageDataUrl);
  } catch (e) {
    console.log("[Navigation] Screenshot capture failed:", e.message);
    // ignore capture errors (e.g., restricted pages)
  }
});

// Receive messages from content or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[Message] Received:", message.type, "from tab:", sender.tab?.id, "payload:", message.payload ? Object.keys(message.payload) : "none");
  (async () => {
    try {
      switch (message.type) {
        case "PG_SAVE_FORENSICS":
          console.log("[Message] Handling PG_SAVE_FORENSICS");
          await handleSaveForensics(sender.tab, message.payload);
          break;
        case "PG_GET_PAGE_STATUS":
          {
            console.log("[Message] Handling PG_GET_PAGE_STATUS for tab:", message.tabId);
            const tabId = message.tabId;
            const status = await getPageStatusForTab(tabId);
            console.log("[Message] Page status result:", status);
            sendResponse(status);
          }
          return true;
        case "PG_USER_CLICKED_LINK":
          console.log("[Message] Handling PG_USER_CLICKED_LINK");
          await handleUserClickedLink(sender.tab, message.payload);
          break;
        case "PG_MONITORING_EVENT":
          console.log("[Message] Handling PG_MONITORING_EVENT");
          await handleMonitoringEvent(message.payload);
          break;
        case "PG_GET_VT_RESULTS":
          {
            console.log("[Message] Handling PG_GET_VT_RESULTS for tab:", message.tabId);
            const tabId = message.tabId;
            const vt = await getVirusTotalResultsForTab(tabId);
            console.log("[Message] VT results:", vt ? "available" : "null");
            sendResponse(vt);
          }
          return true;
        case "PG_UPDATE_VULNERABILITY":
          {
            console.log("[Message] Handling PG_UPDATE_VULNERABILITY");
            const result = await updateUserVulnerability();
            console.log("[Message] Vulnerability update result:", result);
            sendResponse(result);
          }
          return true;
        default:
          console.log("[Message] Unknown message type:", message.type);
          break;
      }
    } catch (error) {
      console.error("[Message] Error handling message:", message.type, error);
    }
  })();

  return true; // keep channel open for async sendResponse
});

// Handle notification clicks
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  console.log("[Notification] Button clicked:", buttonIndex, "on notification:", notificationId);
  if (buttonIndex === 0) {
    // "View Details" button - open popup
    chrome.storage.local.get(null, (data) => {
      // Find the most recent malicious alert data
      const alertKeys = Object.keys(data).filter(k => k.startsWith("malicious_alert_"));
      if (alertKeys.length > 0) {
        const latestKey = alertKeys[alertKeys.length - 1];
        const alertData = data[latestKey];
        chrome.windows.create({
          url: chrome.runtime.getURL("alert.html"),
          type: "popup",
          width: 500,
          height: 400,
          focused: true,
        }, (window) => {
          if (window?.id) {
            chrome.storage.local.set({
              [`malicious_alert_${window.id}`]: alertData
            });
          }
        });
      }
    });
  } else if (buttonIndex === 1) {
    // "Quarantine" button
    chrome.tabs.create({
      url: "https://myaccount.google.com/security"
    });
  }
});

chrome.notifications.onClicked.addListener((notificationId) => {
  console.log("[Notification] Notification clicked:", notificationId);
  // Same as "View Details"
  chrome.storage.local.get(null, (data) => {
    const alertKeys = Object.keys(data).filter(k => k.startsWith("malicious_alert_"));
    if (alertKeys.length > 0) {
      const latestKey = alertKeys[alertKeys.length - 1];
      const alertData = data[latestKey];
      chrome.windows.create({
        url: chrome.runtime.getURL("alert.html"),
        type: "popup",
        width: 500,
        height: 400,
        focused: true,
      }, (window) => {
        if (window?.id) {
          chrome.storage.local.set({
            [`malicious_alert_${window.id}`]: alertData
          });
        }
      });
    }
  });
});

async function handleScreenshot(tabId, url, imageDataUrl) {
  console.log("[Screenshot] Starting screenshot handling for tab:", tabId, "url:", url);
  const user = await getCurrentUser();
  if (!user) {
    console.log("[Screenshot] No user logged in, skipping");
    return;
  }

  // Upload screenshot to Supabase Storage (requires public bucket "screenshots")
  try {
    console.log("[Screenshot] Converting data URL to blob");
    const blob = await (await fetch(imageDataUrl)).blob();
    const filePath = `${user.id}/${Date.now()}_screenshot.png`;
    console.log("[Screenshot] Uploading to Supabase Storage, path:", filePath, "blob size:", blob.size);
    const { data, error } = await supabase.storage
      .from("screenshots")
      .upload(filePath, blob, {
        contentType: "image/png",
      });
    if (error) {
      console.error("[Screenshot] Supabase upload error:", JSON.stringify(error, null, 2));
      // Continue even if upload fails - bucket might not exist yet
      return;
    }
    console.log("[Screenshot] Upload successful, data:", data);
    if (!data || !data.path) {
      console.error("[Screenshot] Upload succeeded but no path returned");
      return;
    }
    const publicUrlResult = supabase.storage.from("screenshots").getPublicUrl(data?.path || filePath);
    const publicUrl = publicUrlResult?.data?.publicUrl || null;
    console.log("[Screenshot] Public URL:", publicUrl);
    if (!publicUrl) {
      console.error("[Screenshot] Failed to get public URL for screenshot");
      return;
    }

    // Attach to latest page_event for this tab if exists
    const pageEventId = await getTabPageEvent(tabId);
    console.log("[Screenshot] Page event ID for tab:", pageEventId);
    if (pageEventId) {
      console.log("[Screenshot] Updating page_event with screenshot_ref");
      const { error: updateError } = await supabase
        .from("page_events")
        .update({ screenshot_ref: publicUrl })
        .eq("id", pageEventId);
      if (updateError) {
        console.error("[Screenshot] Failed to update page_event:", updateError);
      } else {
        console.log("[Screenshot] Successfully updated page_event with screenshot_ref");
      }
    } else {
      console.log("[Screenshot] No page_event_id found for this tab, skipping update");
    }
  } catch (e) {
    console.error("[Screenshot] Exception in screenshot handling:", e);
  }
}

async function handleSaveForensics(tab, payload) {
  console.log("[Forensics] Starting handleSaveForensics for tab:", tab?.id, "url:", payload.url || tab?.url);
  const user = await getCurrentUser();
  if (!user) {
    console.log("[Forensics] No user logged in, skipping");
    return;
  }

  const url = payload.url || tab?.url || "";
  if (!url.startsWith("http")) {
    console.log("[Forensics] URL doesn't start with http, skipping:", url);
    return;
  }

  const domain = new URL(url).hostname;
  console.log("[Forensics] Extracted domain:", domain);
  console.log("[Forensics] Payload summary:", {
    textLength: payload.fullText?.length || 0,
    linksCount: payload.links?.length || 0,
    attachmentsCount: payload.attachments?.length || 0,
    qrCodesCount: payload.qrCodes?.length || 0,
  });

  console.log("[Forensics] Inserting page_event into Supabase");
  const { data, error } = await supabase
    .from("page_events")
    .insert({
      user_id: user.id,
      url,
      domain,
      full_text: payload.fullText || null,
      html_snapshot_ref: null,
      links: payload.links || [],
      attachments: payload.attachments || [],
      qr_codes: payload.qrCodes || [],
      metadata: payload.metadata || {},
      vt_status: "pending",
    })
    .select("id")
    .single();

  if (error) {
    console.error("[Forensics] Error inserting page_event:", JSON.stringify(error, null, 2));
    return;
  }

  const pageEventId = data.id;
  console.log("[Forensics] Page event created with ID:", pageEventId);
  await setTabPageEvent(tab.id, pageEventId);
  console.log("[Forensics] Stored page_event_id for tab:", tab.id);

  // Kick off Gemini + VirusTotal asynchronously
  console.log("[Forensics] Starting analysis pipelines");
  runAnalysisPipelines(pageEventId, payload);
}

async function runAnalysisPipelines(pageEventId, payload) {
  console.log("[Analysis] Starting analysis pipelines for page_event:", pageEventId);
  try {
    console.log("[Analysis] Running Gemini and VirusTotal in parallel");
    const [gemini, vt] = await Promise.allSettled([
      analyzeWithGemini(pageEventId, payload),
      analyzeWithVirusTotal(pageEventId, payload),
    ]);

    console.log("[Analysis] Gemini result:", gemini.status, gemini.status === "rejected" ? gemini.reason : "fulfilled");
    console.log("[Analysis] VirusTotal result:", vt.status, vt.status === "rejected" ? vt.reason : "fulfilled");

    // After both, compute malicious flag
    console.log("[Analysis] Computing malicious flag");
    await computeMaliciousForPage(pageEventId);
  } catch (e) {
    console.error("[Analysis] Pipeline error:", e);
  }
}

async function analyzeWithGemini(pageEventId, payload) {
  console.log("[Gemini] Starting analysis for page_event:", pageEventId);
  if (!GEMINI_API_KEY) {
    console.log("[Gemini] No API key configured, skipping");
    return;
  }

  const truncatedText =
    (payload.fullText || "").slice(0, 8000) || "No visible text.";
  console.log("[Gemini] Truncated text length:", truncatedText.length);

  const prompt = {
    contents: [
      {
        role: "user",
        parts: [
          {
            text:
              "You are a phishing detection engine. Given the following page content, links, and domains, " +
              "identify the most likely attack type and a phishing risk score from 0 (benign) to 100 (highly malicious). " +
              "Respond ONLY in strict JSON with keys attack_type (string) and phishing_score (integer).\n\n" +
              `Page text:\n${truncatedText}\n\n` +
              `Links:\n${JSON.stringify(payload.links || []).slice(0, 4000)}\n\n`,
          },
        ],
      },
    ],
  };

  const apiUrl = `https://generativelanguage.googleapis.com/v1/models/${encodeURIComponent(
    GEMINI_MODEL
  )}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
  console.log("[Gemini] Calling API:", apiUrl.replace(GEMINI_API_KEY, "***"));

  try {
    const res = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(prompt),
    });
    console.log("[Gemini] API response status:", res.status, res.statusText);
    if (!res.ok) {
      const errorText = await res.text();
      console.error("[Gemini] API error:", errorText);
      return;
    }
    const json = await res.json();
    console.log("[Gemini] API response structure:", Object.keys(json));
    let text =
      json.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    console.log("[Gemini] Extracted text from response:", text.substring(0, 200));
    
    // Strip markdown code blocks if present (```json ... ``` or ``` ... ```)
    text = text.trim();
    if (text.startsWith("```")) {
      // Remove opening ```json or ```
      text = text.replace(/^```(?:json)?\s*/i, "");
      // Remove closing ```
      text = text.replace(/\s*```\s*$/, "");
      text = text.trim();
      console.log("[Gemini] Stripped markdown, cleaned text:", text.substring(0, 200));
    }
    
    let parsed = {};
    try {
      parsed = JSON.parse(text);
      console.log("[Gemini] Parsed JSON:", parsed);
    } catch (e) {
      console.error("[Gemini] Failed to parse response JSON:", e, "Raw text:", text);
      return;
    }
    const attackType = parsed.attack_type || null;
    const score = parseInt(parsed.phishing_score || "0", 10);
    console.log("[Gemini] Extracted - attack_type:", attackType, "phishing_score:", score);

    console.log("[Gemini] Updating page_event with results");
    const { error: updateError } = await supabase
      .from("page_events")
      .update({
        gemini_attack_type: attackType,
        gemini_phishing_score: isNaN(score) ? null : score,
      })
      .eq("id", pageEventId);
    if (updateError) {
      console.error("[Gemini] Failed to update page_event:", updateError);
    } else {
      console.log("[Gemini] Successfully updated page_event");
    }
  } catch (e) {
    console.error("[Gemini] Analysis failed with exception:", e);
  }
}

async function analyzeWithVirusTotal(pageEventId, payload) {
  console.log("[VirusTotal] Starting analysis for page_event:", pageEventId);
  if (!VIRUSTOTAL_API_KEY) {
    console.log("[VirusTotal] No API key configured, skipping");
    return;
  }

  const urlsToCheck = new Set();
  (payload.links || []).forEach((l) => {
    if (l && typeof l === "string" && l.startsWith("http")) {
      urlsToCheck.add(l);
    }
  });
  (payload.attachments || []).forEach((a) => {
    if (a.url && a.url.startsWith("http")) urlsToCheck.add(a.url);
  });
  (payload.qrCodes || []).forEach((q) => {
    if (q.url && q.url.startsWith("http")) urlsToCheck.add(q.url);
  });

  console.log("[VirusTotal] URLs to check:", urlsToCheck.size, Array.from(urlsToCheck).slice(0, 5));

  if (urlsToCheck.size === 0) {
    console.log("[VirusTotal] No URLs to check, marking as complete");
    // nothing to send
    const { error } = await supabase
      .from("page_events")
      .update({ vt_status: "complete", virustotal_score: 0 })
      .eq("id", pageEventId);
    if (error) {
      console.error("[VirusTotal] Failed to update status:", error);
    }
    return;
  }

  const reports = [];
  let maxScore = 0;
  for (const url of urlsToCheck) {
    try {
      console.log("[VirusTotal] Submitting URL:", url);
      const res = await fetch("https://www.virustotal.com/api/v3/urls", {
        method: "POST",
        headers: {
          "x-apikey": VIRUSTOTAL_API_KEY,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ url }),
      });
      console.log("[VirusTotal] Submit response status:", res.status);
      if (!res.ok) {
        const errorText = await res.text();
        console.error("[VirusTotal] Submit error for", url, ":", errorText);
        continue;
      }
      const submitJson = await res.json();
      const analysisId = submitJson.data?.id;
      console.log("[VirusTotal] Analysis ID:", analysisId);
      if (!analysisId) {
        console.log("[VirusTotal] No analysis ID returned, skipping");
        continue;
      }

      // Poll analysis result quickly (for demo)
      console.log("[VirusTotal] Fetching analysis result for ID:", analysisId);
      const analysisRes = await fetch(
        `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
        {
          headers: {
            "x-apikey": VIRUSTOTAL_API_KEY,
          },
        }
      );
      console.log("[VirusTotal] Analysis response status:", analysisRes.status);
      if (!analysisRes.ok) {
        const errorText = await analysisRes.text();
        console.error("[VirusTotal] Analysis error for", url, ":", errorText);
        continue;
      }
      const analysisJson = await analysisRes.json();
      console.log("[VirusTotal] Analysis result structure:", Object.keys(analysisJson));
      reports.push({ url, report: analysisJson });

      const stats =
        analysisJson.data?.attributes?.stats || {};
      const maliciousCount = stats.malicious || 0;
      console.log("[VirusTotal] URL", url, "malicious count:", maliciousCount);
      if (maliciousCount > maxScore) maxScore = maliciousCount;
    } catch (e) {
      console.error("[VirusTotal] Analysis failed for", url, ":", e);
    }
  }

  console.log("[VirusTotal] Final maxScore:", maxScore, "reports count:", reports.length);
  console.log("[VirusTotal] Updating page_event with results");
  const { error: updateError } = await supabase
    .from("page_events")
    .update({
      vt_status: "complete",
      virustotal_report: reports,
      virustotal_score: maxScore,
    })
    .eq("id", pageEventId);
  if (updateError) {
    console.error("[VirusTotal] Failed to update page_event:", updateError);
  } else {
    console.log("[VirusTotal] Successfully updated page_event");
  }
}

async function computeMaliciousForPage(pageEventId) {
  console.log("[Malicious] Computing malicious flag for page_event:", pageEventId);
  const { data, error } = await supabase
    .from("page_events")
    .select(
      "id,user_id,url,domain,full_text,links,attachments,qr_codes,metadata,gemini_attack_type,gemini_phishing_score,virustotal_report,virustotal_score,malicious"
    )
    .eq("id", pageEventId)
    .single();
  if (error || !data) return;

  const gScore = data.gemini_phishing_score || 0;
  const vtScore = data.virustotal_score || 0;

  const malicious = gScore >= 50 || vtScore >= 50;

  if (!malicious || data.malicious) {
    // Either still benign or already marked
    await supabase
      .from("page_events")
      .update({ malicious })
      .eq("id", pageEventId);
    return;
  }

  // Mark page_events and insert into malicious_pages
  console.log("[Malicious] Updating page_events.malicious = true");
  const { error: updateError1 } = await supabase
    .from("page_events")
    .update({ malicious: true })
    .eq("id", pageEventId);
  if (updateError1) {
    console.error("[Malicious] Failed to update page_events:", updateError1);
  }

  const textExcerpt = (data.full_text || "").slice(0, 2000);
  console.log("[Malicious] Text excerpt length:", textExcerpt.length);

  let userEmail = null;
  if (data.user_id) {
    console.log("[Malicious] Fetching user email for user_id:", data.user_id);
    const { data: userRow, error: userError } = await supabase
      .from("users")
      .select("user_email")
      .eq("id", data.user_id)
      .single();
    if (userError) {
      console.error("[Malicious] Failed to fetch user email:", userError);
    } else {
      userEmail = userRow?.user_email || null;
      console.log("[Malicious] User email:", userEmail);
    }
  }

  console.log("[Malicious] Inserting into malicious_pages table");
  const { error: insertErr } = await supabase.from("malicious_pages").insert({
    page_event_id: data.id,
    user_id: data.user_id,
    user_email: userEmail,
    url: data.url,
    domain: data.domain,
    text_excerpt: textExcerpt,
    links: data.links,
    attachments: data.attachments,
    qr_codes: data.qr_codes,
    attack_type: data.gemini_attack_type,
    phishing_score: gScore,
    virustotal_report: data.virustotal_report,
    forensics_metadata: data.metadata,
  });
  if (insertErr) {
    console.error("[Malicious] Error inserting malicious_page:", insertErr);
  } else {
    console.log("[Malicious] Successfully inserted malicious_pages entry");
  }

  // Send SMS alert
  console.log("[Malicious] Sending SMS alert");
  await sendSmsAlert({
    user_email: userEmail,
    url: data.url,
    domain: data.domain,
    attack_type: data.gemini_attack_type,
    phishing_score: gScore,
    vt_score: vtScore,
  });

  // Mark SMS as sent in page + malicious snapshot
  await supabase
    .from("page_events")
    .update({ sms_sent: true })
    .eq("id", data.id);
  await supabase
    .from("malicious_pages")
    .update({ sms_sent: true })
    .eq("page_event_id", data.id);

  // Show Chrome notification
  console.log("[Malicious] Creating Chrome notification");
  try {
    chrome.notifications.create(
      {
        type: "basic",
        iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
        title: "⚠️ Phishing Guardian Alert",
        message: `Malicious page detected: ${data.domain}\nAttack: ${data.gemini_attack_type || "Unknown"}\nScore: ${gScore}/100`,
        priority: 2,
        buttons: [
          { title: "View Details" },
          { title: "Quarantine" }
        ]
      },
      (notificationId) => {
        console.log("[Malicious] Notification created with ID:", notificationId);
      }
    );
  } catch (e) {
    console.error("[Malicious] Failed to create notification:", e);
  }

  // Create popup window with alert
  console.log("[Malicious] Creating popup alert window");
  try {
    chrome.windows.create(
      {
        url: chrome.runtime.getURL("alert.html"),
        type: "popup",
        width: 500,
        height: 400,
        focused: true,
      },
      (window) => {
        console.log("[Malicious] Popup window created:", window?.id);
        // Store malicious page data for the alert window
        if (window?.id) {
          chrome.storage.local.set({
            [`malicious_alert_${window.id}`]: {
              url: data.url,
              domain: data.domain,
              attackType: data.gemini_attack_type,
              phishingScore: gScore,
              vtScore: vtScore,
              userEmail: userEmail,
            }
          });
        }
      }
    );
  } catch (e) {
    console.error("[Malicious] Failed to create popup window:", e);
  }

  // Notify any tabs showing this URL to display malicious overlays
  console.log("[Malicious] Notifying tabs with URL:", data.url);
  try {
    chrome.tabs.query({ url: data.url }, (tabs) => {
      console.log("[Malicious] Found", tabs.length, "tabs with this URL");
      tabs.forEach((tab) => {
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: "PG_SHOW_MALICIOUS_ALERT",
            payload: {
              attackType: data.gemini_attack_type,
              phishingScore: gScore,
            },
          });
        } catch (e) {
          console.log("[Malicious] Failed to send message to tab:", tab.id, e.message);
        }
      });
    });
  } catch (e) {
    console.error("[Malicious] Failed to query tabs:", e);
  }
}

async function sendSmsAlert(payload) {
  console.log("[SMS] Preparing SMS alert:", payload);
  // Note: SMS API integration needs to be configured
  // For now, just log the alert details
  console.log("[SMS] Would send SMS to", ALERT_PHONE_NUMBER, "with:", payload);
  if (!SMS_API_URL || !SMS_API_KEY) return;

  try {
    const text =
      `PhishingGuardian Alert\n` +
      `User: ${payload.user_email || "unknown"}\n` +
      `URL: ${payload.url}\n` +
      `Domain: ${payload.domain}\n` +
      `Attack: ${payload.attack_type || "unknown"}\n` +
      `Gemini Score: ${payload.phishing_score}\n` +
      `VT Score: ${payload.vt_score}`;

    await fetch(SMS_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${SMS_API_KEY}`,
      },
      body: JSON.stringify({
        to: ALERT_PHONE_NUMBER,
        message: text,
      }),
    });
  } catch (e) {
    console.error("Failed to send SMS alert", e);
  }
}

async function getPageStatusForTab(tabId) {
  const pageEventId = await getTabPageEvent(tabId);
  if (!pageEventId) return null;
  const { data, error } = await supabase
    .from("page_events")
    .select(
      "id,url,domain,gemini_attack_type,gemini_phishing_score,virustotal_score,malicious,vt_status"
    )
    .eq("id", pageEventId)
    .single();
  if (error) return null;
  return data;
}

async function getVirusTotalResultsForTab(tabId) {
  const pageEventId = await getTabPageEvent(tabId);
  if (!pageEventId) return null;
  const { data, error } = await supabase
    .from("page_events")
    .select("virustotal_report,vt_status")
    .eq("id", pageEventId)
    .single();
  if (error) return null;
  return data;
}

async function handleUserClickedLink(tab, payload) {
  const pageEventId = await getTabPageEvent(tab.id);
  if (!pageEventId) return;
  const { data, error } = await supabase
    .from("page_events")
    .select("id,user_id,malicious")
    .eq("id", pageEventId)
    .single();
  if (error || !data) return;

  if (!data.malicious) return;

  // Increment risk_score
  if (data.user_id) {
    await supabase.rpc("increment_user_risk_score", {
      target_user_id: data.user_id,
    }).catch(() => {});
  }

  // Tell content script to start intensive monitoring
  chrome.tabs.sendMessage(tab.id, {
    type: "PG_START_MONITORING",
    payload: { pageEventId },
  });
}

async function handleMonitoringEvent(payload) {
  // payload: { userId, pageEventId, eventType, eventPayload, logFileRef? }
  console.log("[Monitoring] Received event:", payload.eventType, "for page_event:", payload.pageEventId);
  const { userId, pageEventId, eventType, eventPayload, logFileRef } = payload;
  const { error } = await supabase.from("interaction_log").insert({
    user_id: userId || null,
    page_event_id: pageEventId,
    event_type: eventType,
    payload: eventPayload,
    log_file_ref: logFileRef || null,
  });
  if (error) {
    console.error("[Monitoring] Failed to insert interaction_log:", error);
  } else {
    console.log("[Monitoring] Successfully logged event");
  }
}

// Update users.vulnerability based on browsing history and prior malicious interactions
async function updateUserVulnerability() {
  const user = await getCurrentUser();
  if (!user) {
    return { error: "not_logged_in" };
  }

  try {
    const historyItems = await new Promise((resolve) => {
      const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
      chrome.history.search(
        {
          text: "",
          startTime: thirtyDaysAgo,
          maxResults: 200,
        },
        (items) => resolve(items || [])
      );
    });

    const historySummary = historyItems
      .map((h) => `${h.url} ${h.title || ""}`)
      .join("\n")
      .slice(0, 8000);

    const { data: maliciousClicks } = await supabase
      .from("interaction_log")
      .select("id,created_at,payload")
      .limit(50)
      .order("created_at", { ascending: false });

    const behaviorSummary = JSON.stringify(maliciousClicks || []).slice(
      0,
      4000
    );

    const prompt = {
      contents: [
        {
          role: "user",
          parts: [
            {
              text:
                "You are a security assistant. Based on the user's browsing history and interactions on malicious pages, " +
                "describe in a short paragraph what kinds of phishing or social engineering attacks this user is most vulnerable to. " +
                "Focus on behavioral patterns, not specific URLs.\n\n" +
                `Browsing history (last 30 days):\n${historySummary}\n\n` +
                `Recent interactions on malicious pages:\n${behaviorSummary}\n`,
            },
          ],
        },
      ],
    };

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/${encodeURIComponent(
        GEMINI_MODEL
      )}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(prompt),
      }
    );
    if (!res.ok) {
      console.error("Gemini vulnerability API error", await res.text());
      return { error: "gemini_error" };
    }
    const json = await res.json();
    const text =
      json.candidates?.[0]?.content?.parts?.[0]?.text ||
      "No specific vulnerabilities identified.";

    await supabase
      .from("users")
      .update({ vulnerability: text })
      .eq("id", user.id);

    return { vulnerability: text };
  } catch (e) {
    console.error("Failed to update vulnerability", e);
    return { error: "unknown_error" };
  }
}


