# Phishing Monitoring Browser Extension

## Setup Instructions

### 1. Supabase Database Setup

#### Option A: Using Supabase Dashboard (Easiest)
1. Go to https://supabase.com/dashboard
2. Select your project
3. Navigate to **SQL Editor** in the left sidebar
4. Click **New query**
5. Copy and paste the entire contents of `supabase.schema.sql`
6. Click **Run** (or press Ctrl+Enter)

#### Option B: Using Supabase CLI
```bash
# Install Supabase CLI if you haven't
npm install -g supabase

# Login to Supabase
supabase login

# Link to your project
supabase link --project-ref ihvmjcwnmdrpcvkoqhis

# Run the schema
supabase db push --file supabase.schema.sql
```

### 2. Create Storage Buckets

After running the SQL schema, create these storage buckets in Supabase:

1. Go to **Storage** in the Supabase Dashboard
2. Click **New bucket** and create:
   - `screenshots` (public or private, as needed)
   - `html_snapshots` (optional, for HTML snapshots)
   - `interaction_logs` (optional, for text file logs)

For each bucket, you may want to set up policies to allow authenticated users to upload files.

### 3. Configure API Keys

Update the following in `background.js` and `popup.js`:
- ✅ Supabase URL and Anon Key (already configured)
- ✅ Gemini API Key (already configured)
- ✅ VirusTotal API Key (already configured)
- ⚠️ SMS API URL and Key (still needs configuration)

### 4. Load Extension in Chrome

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select this project folder
5. The extension should now appear in your extensions list

### 5. Test the Extension

1. Click the extension icon in Chrome toolbar
2. Register a new user account
3. Log in
4. Browse to any website - the extension will automatically:
   - Extract page forensics
   - Analyze with Gemini AI
   - Check links with VirusTotal
   - Flag malicious pages and show alerts

## Features

- ✅ User registration and login
- ✅ Automatic page forensics extraction
- ✅ Gemini AI phishing detection
- ✅ VirusTotal sandbox analysis
- ✅ Malicious page alerts (popup + persistent)
- ✅ Phishing news widget
- ✅ Risk score tracking
- ✅ User vulnerability profiling
- ✅ SMS alerts for malicious pages
- ✅ Full interaction monitoring on malicious pages

## File Structure

- `manifest.json` - Chrome extension manifest
- `background.js` - Service worker (Supabase, Gemini, VirusTotal, SMS)
- `content.js` - Content script (forensics extraction, alerts, monitoring)
- `popup.html/js/css` - Extension popup UI
- `supabase.schema.sql` - Database schema

## Notes

- Password hashing currently uses a simple base64 encoding for demo purposes. **Replace with proper bcrypt/PBKDF2 before production use.**
- SMS API integration needs to be configured with your SMS provider.
- QR code detection is currently a placeholder - integrate a real QR decoder library if needed.

