-- Supabase schema for phishing monitoring extension

-- Enable UUID extension if not already enabled
create extension if not exists "uuid-ossp";

-- Users table: core user profile and risk info
create table if not exists public.users (
  id uuid primary key default uuid_generate_v4(),
  username text not null,
  user_email text not null unique,
  password_hash text not null,
  admin boolean not null default false,
  vulnerability text,
  risk_score integer not null default 0,
  honeypot boolean not null default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index if not exists idx_users_email on public.users (user_email);

-- Generic trigger to keep updated_at in sync
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = timezone('utc'::text, now());
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_timestamp_users on public.users;
create trigger set_timestamp_users
before update on public.users
for each row
execute procedure public.set_updated_at();

-- Page events table: forensics per page view
create table if not exists public.page_events (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete set null,
  url text not null,
  domain text not null,
  full_text text,
  html_snapshot_ref text,
  screenshot_ref text,
  links jsonb,
  attachments jsonb,
  qr_codes jsonb,
  metadata jsonb,
  gemini_attack_type text,
  gemini_phishing_score integer,
  virustotal_report jsonb,
  virustotal_score integer,
  malicious boolean not null default false,
  vt_status text default 'pending',
  sms_sent boolean not null default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index if not exists idx_page_events_user_id on public.page_events(user_id);
create index if not exists idx_page_events_url on public.page_events(url);
create index if not exists idx_page_events_malicious on public.page_events(malicious);

-- Malicious pages table: snapshot of malicious events
create table if not exists public.malicious_pages (
  id uuid primary key default uuid_generate_v4(),
  page_event_id uuid references public.page_events(id) on delete cascade,
  user_id uuid references public.users(id) on delete set null,
  user_email text,
  url text not null,
  domain text not null,
  text_excerpt text,
  links jsonb,
  attachments jsonb,
  qr_codes jsonb,
  attack_type text,
  phishing_score integer,
  virustotal_report jsonb,
  forensics_metadata jsonb,
  news_shown boolean not null default false,
  sms_sent boolean not null default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index if not exists idx_malicious_pages_user_id on public.malicious_pages(user_id);
create index if not exists idx_malicious_pages_url on public.malicious_pages(url);

-- Interaction log table: events after clicking malicious links
create table if not exists public.interaction_log (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete set null,
  page_event_id uuid references public.page_events(id) on delete cascade,
  event_type text not null,
  payload jsonb not null,
  log_file_ref text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

create index if not exists idx_interaction_log_user_id on public.interaction_log(user_id);
create index if not exists idx_interaction_log_page_event_id on public.interaction_log(page_event_id);

-- Buckets to hold screenshots and logs (to be created via Supabase UI/CLI in storage)
-- Recommended names:
--   - screenshots
--   - html_snapshots
--   - interaction_logs

-- Function to increment user risk score atomically
create or replace function public.increment_user_risk_score(target_user_id uuid)
returns void as $$
begin
  update public.users
  set risk_score = coalesce(risk_score, 0) + 1
  where id = target_user_id;
end;
$$ language plpgsql security definer;



