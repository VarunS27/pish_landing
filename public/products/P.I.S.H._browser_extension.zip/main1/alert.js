// alert.js - handles the malicious page alert popup window

// Get window ID and load malicious page data
chrome.windows.getCurrent((window) => {
  const windowId = window.id;
  console.log("[Alert] Window ID:", windowId);
  
  chrome.storage.local.get([`malicious_alert_${windowId}`], (data) => {
    const alertData = data[`malicious_alert_${windowId}`];
    console.log("[Alert] Loaded alert data:", alertData);
    
    if (alertData) {
      document.getElementById("alert-url").textContent = alertData.url || "Unknown";
      document.getElementById("alert-domain").textContent = alertData.domain || "Unknown";
      document.getElementById("alert-attack-type").textContent = alertData.attackType || "Unknown";
      document.getElementById("alert-phishing-score").textContent = `${alertData.phishingScore ?? "N/A"}/100`;
      document.getElementById("alert-vt-score").textContent = `${alertData.vtScore ?? "N/A"}/100`;
      
      // Clean up stored data
      chrome.storage.local.remove([`malicious_alert_${windowId}`]);
    } else {
      console.error("[Alert] No alert data found for window:", windowId);
      document.getElementById("alert-url").textContent = "Data not available";
    }
  });
});

// Quarantine button
document.getElementById("quarantine-btn").addEventListener("click", () => {
  console.log("[Alert] Quarantine button clicked");
  chrome.tabs.create({
    url: "https://myaccount.google.com/security"
  });
  window.close();
});

// Close button
document.getElementById("close-btn").addEventListener("click", () => {
  console.log("[Alert] Close button clicked");
  window.close();
});

