// popup.js - handles register/login and current page status

import { createClient } from "./supabase-client.js";

// Mirror config from background.js (keep in sync)
const SUPABASE_URL = "https://ihmvjcwnmdrpcvkoqhis.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlobXZqY3dubWRycGN2a29xaGlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ1ODUxNTAsImV4cCI6MjA4MDE2MTE1MH0.LaUr84Lw3LzeqBjfKi7Lf-CZf62LyhcrzOJ3ZuYO-pE";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const mainEl = document.getElementById("pg-main");

function hashPassword(pw) {
  return btoa(pw); // TODO: replace with a real hash (e.g., bcrypt/PBKDF2). For demo only.
}

async function getStoredUser() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["pg_user"], (data) => {
      resolve(data.pg_user || null);
    });
  });
}

async function setStoredUser(user) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ pg_user: user }, () => resolve());
  });
}

function renderAuthTabs(activeTab) {
  mainEl.innerHTML = "";
  const tabs = document.createElement("div");
  tabs.className = "pg-tabs";
  const tabLogin = document.createElement("div");
  tabLogin.className =
    "pg-tab " + (activeTab === "login" ? "pg-active" : "");
  tabLogin.textContent = "Login";
  const tabRegister = document.createElement("div");
  tabRegister.className =
    "pg-tab " + (activeTab === "register" ? "pg-active" : "");
  tabRegister.textContent = "Register";
  tabs.appendChild(tabLogin);
  tabs.appendChild(tabRegister);
  mainEl.appendChild(tabs);

  tabLogin.onclick = () => renderAuthTabs("login");
  tabRegister.onclick = () => renderAuthTabs("register");

  if (activeTab === "login") {
    renderLoginForm();
  } else {
    renderRegisterForm();
  }
}

function renderRegisterForm() {
  const form = document.createElement("div");
  form.innerHTML = `
    <div class="pg-field">
      <label>Username</label>
      <input type="text" id="pg-reg-username" />
    </div>
    <div class="pg-field">
      <label>Email</label>
      <input type="email" id="pg-reg-email" />
    </div>
    <div class="pg-field">
      <label>Password</label>
      <input type="password" id="pg-reg-password" />
    </div>
    <div class="pg-field">
      <label>Confirm Password</label>
      <input type="password" id="pg-reg-password2" />
    </div>
    <button class="pg-btn pg-btn-primary" id="pg-reg-submit">Register</button>
    <div id="pg-reg-msg"></div>
  `;
  mainEl.appendChild(form);

  document
    .getElementById("pg-reg-submit")
    .addEventListener("click", async () => {
      const username = document.getElementById("pg-reg-username").value.trim();
      const email = document.getElementById("pg-reg-email").value.trim();
      const pw = document.getElementById("pg-reg-password").value;
      const pw2 = document.getElementById("pg-reg-password2").value;
      const msgEl = document.getElementById("pg-reg-msg");
      msgEl.className = "";
      msgEl.textContent = "";

      if (!username || !email || !pw) {
        msgEl.className = "pg-error";
        msgEl.textContent = "All fields are required.";
        return;
      }
      if (pw !== pw2) {
        msgEl.className = "pg-error";
        msgEl.textContent = "Passwords do not match.";
        return;
      }

      try {
        console.log("[Popup] Starting registration for:", email);
        const passwordHash = hashPassword(pw);
        console.log("[Popup] Password hashed, length:", passwordHash.length);
        console.log("[Popup] Inserting user into Supabase");
        const { data, error } = await supabase
          .from("users")
          .insert({
            username,
            user_email: email,
            password_hash: passwordHash,
            admin: false,
            vulnerability: null,
            risk_score: 0,
            honeypot: false,
          })
          .select("id,username,user_email,risk_score")
          .single();
        if (error) {
          console.error("[Popup] Registration error:", error);
          msgEl.className = "pg-error";
          msgEl.textContent = "Registration failed: " + error.message;
          return;
        }
        console.log("[Popup] Registration successful, user ID:", data.id);
        await setStoredUser({
          id: data.id,
          username: data.username,
          user_email: data.user_email,
          risk_score: data.risk_score,
        });
        console.log("[Popup] User stored in chrome.storage");
        msgEl.className = "pg-success";
        msgEl.textContent = "Registered successfully.";
        renderMainPanel();
      } catch (e) {
        msgEl.className = "pg-error";
        msgEl.textContent = "Registration error.";
      }
    });
}

function renderLoginForm() {
  const form = document.createElement("div");
  form.innerHTML = `
    <div class="pg-field">
      <label>Email</label>
      <input type="email" id="pg-login-email" />
    </div>
    <div class="pg-field">
      <label>Password</label>
      <input type="password" id="pg-login-password" />
    </div>
    <button class="pg-btn pg-btn-primary" id="pg-login-submit">Login</button>
    <div id="pg-login-msg"></div>
  `;
  mainEl.appendChild(form);

  document
    .getElementById("pg-login-submit")
    .addEventListener("click", async () => {
      const email = document.getElementById("pg-login-email").value.trim();
      const pw = document.getElementById("pg-login-password").value;
      const msgEl = document.getElementById("pg-login-msg");
      msgEl.className = "";
      msgEl.textContent = "";
      if (!email || !pw) {
        msgEl.className = "pg-error";
        msgEl.textContent = "Email and password required.";
        return;
      }
      try {
        console.log("[Popup] Starting login for:", email);
        const { data, error } = await supabase
          .from("users")
          .select("id,username,user_email,password_hash,risk_score")
          .eq("user_email", email)
          .single();
        if (error || !data) {
          console.error("[Popup] Login error - user not found or query error:", error);
          msgEl.className = "pg-error";
          msgEl.textContent = "Invalid credentials.";
          return;
        }
        console.log("[Popup] User found, ID:", data.id);
        const passwordHash = hashPassword(pw);
        if (passwordHash !== data.password_hash) {
          console.log("[Popup] Password hash mismatch");
          msgEl.className = "pg-error";
          msgEl.textContent = "Invalid credentials.";
          return;
        }
        console.log("[Popup] Password verified, storing user session");
        await setStoredUser({
          id: data.id,
          username: data.username,
          user_email: data.user_email,
          risk_score: data.risk_score,
        });
        msgEl.className = "pg-success";
        msgEl.textContent = "Logged in.";
        renderMainPanel();
      } catch (e) {
        msgEl.className = "pg-error";
        msgEl.textContent = "Login error.";
      }
    });
}

async function renderMainPanel() {
  const user = await getStoredUser();
  if (!user) {
    renderAuthTabs("login");
    return;
  }

  mainEl.innerHTML = "";

  const info = document.createElement("div");
  info.innerHTML = `
    <div><strong>User:</strong> ${user.username} (${user.user_email})</div>
    <div><strong>Risk score:</strong> <span id="pg-risk-score">${
      user.risk_score ?? 0
    }</span></div>
  `;
  mainEl.appendChild(info);

  const actions = document.createElement("div");
  actions.style.marginTop = "8px";
  actions.innerHTML = `
    <button class="pg-btn pg-btn-secondary" id="pg-logout">Logout</button>
    <button class="pg-btn pg-btn-primary" id="pg-quarantine">Quarantine (Google)</button>
  `;
  mainEl.appendChild(actions);

  document.getElementById("pg-logout").onclick = async () => {
    await setStoredUser(null);
    renderAuthTabs("login");
  };
  document.getElementById("pg-quarantine").onclick = () => {
    chrome.tabs.create({
      url: "https://myaccount.google.com/security",
    });
  };

  const status = document.createElement("div");
  status.className = "pg-status";
  status.innerHTML = `
    <div><strong>Current page status</strong></div>
    <div id="pg-page-status">Loading...</div>
    <button class="pg-btn pg-btn-secondary" id="pg-vt-btn" disabled>View VirusTotal results</button>
    <div id="pg-vt-results" style="margin-top:4px;font-size:12px;"></div>
  `;
  mainEl.appendChild(status);

  // Load status for current tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    chrome.runtime.sendMessage(
      { type: "PG_GET_PAGE_STATUS", tabId: tab.id },
      (resp) => {
        if (chrome.runtime.lastError) {
          document.getElementById("pg-page-status").textContent =
            "Error: " + chrome.runtime.lastError.message;
          return;
        }
        const sEl = document.getElementById("pg-page-status");
        const vtBtn = document.getElementById("pg-vt-btn");
        if (!resp) {
          sEl.textContent = "No analysis yet for this page.";
          vtBtn.disabled = true;
          return;
        }
        const maliciousLabel = resp.malicious ? "MALICIOUS" : "Safe";
        sEl.textContent = `${maliciousLabel} | Attack: ${
          resp.gemini_attack_type || "Unknown"
        } | G-score: ${
          resp.gemini_phishing_score ?? "N/A"
        } | VT-score: ${resp.virustotal_score ?? "N/A"}`;

        if (resp.vt_status === "complete") {
          vtBtn.disabled = false;
        } else {
          vtBtn.disabled = true;
        }
      }
    );
  });

  document.getElementById("pg-vt-btn").onclick = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      chrome.runtime.sendMessage(
        { type: "PG_GET_VT_RESULTS", tabId: tab.id },
        (resp) => {
          if (chrome.runtime.lastError) {
            document.getElementById("pg-vt-results").textContent =
              "Error: " + chrome.runtime.lastError.message;
            return;
          }
          const vtEl = document.getElementById("pg-vt-results");
          if (!resp || resp.vt_status !== "complete") {
            vtEl.textContent = "VirusTotal results not available yet.";
            return;
          }
          vtEl.textContent = "";
          const pre = document.createElement("pre");
          pre.style.whiteSpace = "pre-wrap";
          pre.style.maxHeight = "150px";
          pre.style.overflow = "auto";
          pre.textContent = JSON.stringify(resp.virustotal_report, null, 2);
          vtEl.appendChild(pre);
        }
      );
    });
  };

  // Vulnerability section
  const vuln = document.createElement("div");
  vuln.className = "pg-status";
  vuln.innerHTML = `
    <div><strong>User vulnerability profile</strong></div>
    <div id="pg-vuln-text">Loading...</div>
    <button class="pg-btn pg-btn-secondary" id="pg-vuln-update">Update from history</button>
  `;
  mainEl.appendChild(vuln);

  document.getElementById("pg-vuln-update").onclick = () => {
    const el = document.getElementById("pg-vuln-text");
    el.textContent = "Updating...";
    chrome.runtime.sendMessage(
      { type: "PG_UPDATE_VULNERABILITY" },
      (resp) => {
        if (chrome.runtime.lastError) {
          el.textContent = "Error: " + chrome.runtime.lastError.message;
          return;
        }
        if (!resp || resp.error) {
          el.textContent = "Failed to update vulnerability.";
        } else {
          el.textContent = resp.vulnerability;
        }
      }
    );
  };

  // Load existing vulnerability from Supabase
  (async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("vulnerability")
        .eq("id", user.id)
        .single();
      const el = document.getElementById("pg-vuln-text");
      if (error || !data || !data.vulnerability) {
        el.textContent = "No vulnerability profile yet.";
      } else {
        el.textContent = data.vulnerability;
      }
    } catch (e) {
      const el = document.getElementById("pg-vuln-text");
      el.textContent = "Failed to load vulnerability.";
    }
  })();
}

(async () => {
  const user = await getStoredUser();
  if (!user) {
    renderAuthTabs("login");
  } else {
    renderMainPanel();
  }
})();


